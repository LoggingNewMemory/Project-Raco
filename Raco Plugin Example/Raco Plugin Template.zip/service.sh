#!/system/bin/sh
# Use Shell (Do not use Magisk Module Syntax)
# No need to wait boot complete as this will executed with the main Raco service.sh
