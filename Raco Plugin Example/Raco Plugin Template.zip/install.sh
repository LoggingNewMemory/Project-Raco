#!/system/bin/sh
# Use Shell (Do not use Magisk Module Syntax)
